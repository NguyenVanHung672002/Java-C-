﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<sinhVien> studentsLeft = new List<sinhVien>();
        List<sinhVien> studentsRight = new List<sinhVien>();
        public MainWindow()
        {
            InitializeComponent();

            studentsLeft.Add(new sinhVien("1", "Ten 1", 10));
            studentsLeft.Add(new sinhVien("2", "Ten 2", 11));
            studentsLeft.Add(new sinhVien("3", "Ten 3", 12));
            studentsLeft.Add(new sinhVien("4", "Ten 4", 13));
            leftBox.DataContext = studentsLeft;
            rightBox.DataContext = studentsRight;
        }
        // tranRight
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            sinhVien temp = (sinhVien)leftBox.SelectedItem;
            studentsRight.Add(temp);
            rightBox.Items.Refresh();
            studentsLeft.Remove(temp);
            leftBox.Items.Refresh();
        }
        // tranLeft
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            sinhVien temp = (sinhVien)rightBox.SelectedItem;
            studentsLeft.Add(temp);
            leftBox.Items.Refresh();
            studentsRight.Remove(temp);
            rightBox.Items.Refresh();
        }
        //search Id
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string id = txtIdSearch.Text;
            foreach(sinhVien sv in studentsLeft)
            {
                if(sv.Id == id)
                {
                    studentsRight.Add(sv);
                    rightBox.Items.Refresh();
                }
            }
        }
        // Add
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string id = txtId.Text;
            string name = txtName.Text;
            int age = int.Parse(txtAge.Text);
            studentsRight.Add(new sinhVien(id, name, age));
            rightBox.Items.Refresh();
        }
        // tranAll
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            foreach(sinhVien sv in studentsLeft)
            {
                studentsRight.Add(sv);
            }
            studentsLeft.Clear();
            leftBox.Items.Refresh();
            rightBox.Items.Refresh();
        }
        // getInfo
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            var sv = (sinhVien)leftBox.SelectedItem;
            txtId.Text = sv.Id;
            txtName.Text = sv.Name;
            txtAge.Text = Convert.ToString(sv.Age);
        }
        

    }
}
